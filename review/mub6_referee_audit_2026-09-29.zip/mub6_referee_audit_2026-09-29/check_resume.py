"""Synthetic regression for failed-record resumption; original results untouched."""
import sys, json, tempfile
from pathlib import Path
from types import SimpleNamespace
import numpy as np
sys.path.insert(0,sys.argv[1])
import driver
record={'lev':9,'idx':[1,2,3,4],'ok':False,'refined':True}
with tempfile.TemporaryDirectory() as td:
    file=Path(td)/'results.jsonl'; file.write_text(json.dumps(record)+'\n')
    original=driver.RESULTS
    try:
        driver.RESULTS=str(file)
        done=driver.done_set()
        p=SimpleNamespace(lev=9,idx=np.array(record['idx']))
        result=driver.certify_box(p,None,7,None,done)
    finally:
        driver.RESULTS=original
print(json.dumps({'synthetic_record':record,'failed_key_in_done_set':(9,tuple(record['idx'])) in done,
'certify_box_return_n_ok_n_fail':result,
'qualification':'A resumption defect. All 15648 submitted merged records have ok=true, so this test does not show contamination of the submitted final run.'},indent=2))
assert result==(1,0)
