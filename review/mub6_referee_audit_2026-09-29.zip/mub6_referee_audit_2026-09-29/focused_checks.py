"""Reproducible referee counterexamples. Does not alter submitted code."""
import sys, json
from fractions import Fraction as Q
import numpy as np
sys.path.insert(0,sys.argv[1])
import rig, pipeline
r=1.0+2.0**-52
m,rad=rig.dmul(0j,r,0j,r)
exact=Q.from_float(r)**2
returned=Q.from_float(float(rad))
Am=np.array([[0.0]]); Ar=np.array([[r]])
cm,cr=rig.imatmul(Am,Ar,Am,Ar)
# Also test with the left radius identically zero, as on active call sites.
cm0,cr0=rig.imatmul(np.array([[r]]),np.zeros((1,1)),np.zeros((1,1)),np.array([[r]]))
lo=np.tile(np.array([1000,65000])[:,None],(1,5))
hi=np.tile(np.array([1100,68000])[:,None],(1,5))
hlo,hhi=pipeline.cyclic_hull(lo,hi)
x=2000
covered_by_input=any(((x-int(a))%65536)<=int(b-a) for a,b in zip(lo[:,0],hi[:,0]))
covered_by_output=((x-int(hlo[0]))%65536)<=int(hhi[0]-hlo[0])
out={
 'dmul':{'radius_input':r.hex(),'computed_midpoint':str(m),'computed_radius':float(rad).hex(),'exact_product_radius':str(exact),'shortfall_exact':str(exact-returned),'shortfall_float':float(exact-returned),'valid_enclosure':returned>=exact},
 'imatmul':{'computed_radius':float(cr[0,0]).hex(),'shortfall_exact':str(exact-Q.from_float(float(cr[0,0]))),'valid_enclosure':Q.from_float(float(cr[0,0]))>=exact},
 'imatmul_zero_left_radius':{'computed_radius':float(cr0[0,0]).hex(),'shortfall_exact':str(exact-Q.from_float(float(cr0[0,0]))),'valid_enclosure':Q.from_float(float(cr0[0,0]))>=exact},
 'cyclic_hull':{'period':65536,'input_intervals':[[1000,1100],[65000,68000]],'output_interval':[int(hlo[0]),int(hhi[0])],'witness_mod_period':x,'input_contains_witness':bool(covered_by_input),'output_contains_witness':bool(covered_by_output),'qualification':'This generic failure can omit the declared ball in solve.child_box. It does not establish loss of attached non-wrapping dyadic boxes on the active path.'}}
print(json.dumps(out,indent=2))
