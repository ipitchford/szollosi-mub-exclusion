"""Independently checks the supplied table using mpmath interval arithmetic, not Arb.
Every stored binary64 component is imported exactly; each interval difference
must be bounded by 2**-53. No numerical point comparison is substituted for
an interval comparison. This is a software-level check, not a formal proof of
mpmath's interval implementation.
"""
from pathlib import Path
import argparse, time, json
import numpy as np
import mpmath as mp
p=argparse.ArgumentParser(); p.add_argument('table'); args=p.parse_args()
mp.iv.dps=40
T=np.load(args.table)
assert T.shape==(131072,) and T.dtype==np.complex128
bound=mp.iv.mpf(2)**-53
bad=[]; t0=time.time()
for m in range(len(T)):
    theta=2*mp.iv.pi*m/len(T)
    for component, exact, stored in [('real',mp.iv.cos(theta),T[m].real),('imag',mp.iv.sin(theta),T[m].imag)]:
        err=abs(exact-mp.iv.mpf(float(stored)))
        if not bool(err.b<=bound): bad.append((m,component,str(err)))
print(json.dumps({'method':'mpmath.iv, 40 decimal digits','mpmath':mp.__version__,'entries':len(T),'component_checks':2*len(T),'bound':'2^-53','failed':len(bad),'failures':bad[:20],'seconds':time.time()-t0},indent=2))
raise SystemExit(bool(bad))
