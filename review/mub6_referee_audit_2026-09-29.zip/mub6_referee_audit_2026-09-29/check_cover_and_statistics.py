"""Audit submitted result-set coverage against its supplied parameter selector.
This checks combinatorial completeness, not numerical soundness of that selector.
"""
import os, sys, json, time
from collections import Counter
from pathlib import Path
import numpy as np
if len(sys.argv) != 2:
    raise SystemExit('Usage: python check_cover_and_statistics.py /path/to/extracted/mub6_szollosi_conjecture3')
BASE=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(BASE/'code'))
from parambox2 import leaves2, test_boxes2
start=time.time()
rows=[json.loads(s) for s in (BASE/'results/results_merged.jsonl').open() if s.strip()]
keys=[(r['lev'],tuple(r['idx'])) for r in rows]
assert len(set(keys))==len(rows)
assert all(r['ok'] and r['lev']==9 for r in rows)
roots=leaves2(7,verbose=True)
offsets=np.indices((4,4,4,4)).reshape(4,-1).T
kept=[]
for j in range(0,len(roots),40):
    children=(roots[j:j+40,None,:]*4+offsets[None,:,:]).reshape(-1,4)
    kept.extend(map(tuple,children[test_boxes2(children,9)]))
expected=set(kept)
actual={k[1] for k in keys}
assert len(expected)==len(kept)
root_counts=Counter(tuple(i//4 for i in x) for x in expected)
stat={'records':len(rows),'unique_records':len(set(keys)),'all_ok':all(r['ok'] for r in rows),
'level_counts':dict(Counter(r['lev'] for r in rows)),'roots_L7':len(roots),
'all_L9_descendants_tested':len(roots)*256,'kept_L9_descendants':len(expected),
'missing_result_keys':len(expected-actual),'extra_result_keys':len(actual-expected),
'roots_with_kept_children':len(root_counts),'roots_without_kept_children':len(roots)-len(root_counts),
'keys_in_first_row':list(rows[0]),
'elapsed_seconds':round(time.time()-start,2),
'limitation':'Reuses submitted parameter exclusion tests; not an independent rigorous interval proof of those exclusions.'}
print(json.dumps(stat,indent=2))
Path(__file__).resolve().with_name('cover_statistics.json').write_text(json.dumps(stat,indent=2)+'\n')
assert not(expected-actual) and not(actual-expected)
