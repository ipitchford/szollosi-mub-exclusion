# Referee audit: Szöllősi-family MUB exclusion

Review date: 29 September 2026.

Input: `mub6_szollosi_conjecture3.zip`.
SHA-256: `944044376cda648e37b1f27aa7fd8514b56d4d8ba42ecab46f13f4afb3a82c0b`.

This supplement records checks made during an academic review. It does not replace the submitted bundle, and the submitted source code was not edited. It is not a proof of the exclusion theorem and contains no counterexample to the mathematical conjecture.

## Completed checks

- All 63 entries in the supplied MD5 manifest matched.
- Independently checked all 131,072 complex entries / 262,144 real components of `table17.npy` using mpmath interval arithmetic at 40 decimal digits. Every component was enclosed within 2^-53 of its exact trigonometric target. This is a software-level interval check, not a formal verification of mpmath. The original Arb checker was not executed because python-flint was unavailable.
- Re-ran the supplied set-based clique verifier over every stored nonempty certificate: 15,510 records, at most 141 hulls, 6,628,140 six-cliques, zero reported problems. This independently re-enumerates the combinatorics relative to the bitset implementation, but reuses the supplied geometry, interval bounds and graph construction.
- Compared the 15,648 unique successful level-9 records with all 422,400 level-9 descendants of the supplied selector's 1,650 level-7 roots. Exactly 15,648 descendants were retained; zero missing and zero extra records. This establishes bookkeeping completeness relative to that selector, not numerical soundness of its exclusions.
- Re-ran the supplied numerical symmetry checks (200 random parameter points) and self-tests with seed 20260929 and count 12. The latter reported 2,160 solution-containing boxes, 34,560 pair checks, 60 surface-point tests and 12 random-graph comparisons, with zero failures. These are numerical consistency tests, not exhaustive verification.
- Executed exact/adversarial regression examples in `focused_checks.py` and `check_resume.py`, described below.

## Exact enclosure counterexamples

Set r = 1 + 2^-52, exactly representable in binary64.
`rig.dmul(0j, r, 0j, r)` returns radius 1 + 2^-51, although the exact product of the input discs has radius r^2 = 1 + 2^-51 + 2^-104. The radius falls short by exactly 2^-104.

The same defect occurs for the one-by-one matrix-radius product. In particular, it also occurs with **zero left radius**, using A_mid = r, A_rad = 0, B_mid = 0 and B_rad = r. Thus the zero-left-radius invariant alone does not repair the generic matrix-product contract.

These examples falsify the generic outward-enclosure contract. They do not establish that the submitted run encountered these particular inputs or made an incorrect exclusion. A repair must use rigorous outward evaluation, or prove adequate bounds/invariants for every reachable call and final comparison.

## Cyclic-hull counterexample and limitation

On the period-65536 grid, use intervals [1000,1100] and [65000,68000], repeated in all five coordinates. `pipeline.cyclic_hull` returns [65000,66636]. The input union contains the residue 2000; the returned hull does not.

This falsifies the documented generic containment contract. The active grouping path has a narrower input structure: one possibly wrapping declared ball plus nonwrapping retained dyadic boxes. The example does **not** prove loss of a retained dyadic solution box on that path. Repair the generic function or prove and test the narrower invariant actually required.

## Resumption counterexample and limitation

A temporary results file containing `{"lev":9,"idx":[1,2,3,4],"ok":false,"refined":true}` is treated by `driver.done_set` as done, and `driver.certify_box` returns one success and zero failures for that key without checking its descendants.

All 15,648 supplied final merged records have `ok=true`. The synthetic regression does not demonstrate contamination of that final run. It demonstrates unsafe resumption semantics, relevant to reproducibility and future reruns.

## Evidence limits

The entire phase-space branch-and-bound computation was **not** rerun. Stored final hulls do not contain a complete trace of every discarded phase box, and 138 empty-hull records carry no geometry for a standalone phase-exhaustion replay. The supplied coverage checker reuses the original selector; the clique checker reuses numerical geometry and graph bounds. Therefore the completed checks must not be called an independent end-to-end proof verification.

A time-limited original `verify_cover.py` invocation was superseded by the completed vectorised bookkeeping audit. Its incomplete log and stale process-status records are intentionally excluded from this supplement.

## Reproduction

Dependencies: Python, NumPy, SciPy, and mpmath. Tested versions appear in `environment_and_statistics.json`. Unpack the original submission first. Run:

```sh
bash run_checks.sh /absolute/path/to/mub6_szollosi_conjecture3
```

The script first checks the entire unit table independently. Only after that succeeds does it set the submitted implementation's `MUB6_SKIP_TABLE_VERIFY=1` flag to avoid the unavailable Arb dependency. It does not run the full original proof search. Outputs overwrite the corresponding audit logs next to the script.

`focused_checks.py` and `check_resume.py` intentionally report the detected defects; a successful script execution does not mean those contracts passed. Inspect their JSON output.

## Reported manuscript statistics

`environment_and_statistics.json` contains the full numerical-solution-count histogram. The seven dominant categories listed in the paper total 15,580 records; another 68 records have other counts. These are numerical search counts, not certified numbers of exact solutions.

## Interpretation

The mathematical reduction and the checked combinatorics provide substantial positive evidence. The arithmetic, selector-bound and verification-scope issues prevent treating this audit as confirmation of the claimed certified theorem. The referee recommendation is major revisions; no counterexample to the Szöllősi-family exclusion itself was found.
