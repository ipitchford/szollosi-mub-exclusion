#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Usage: bash run_checks.sh /absolute/path/to/mub6_szollosi_conjecture3" >&2
  exit 2
fi
BUNDLE="$(cd "$1" && pwd)"
AUDIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
(cd "$BUNDLE" && md5sum -c MD5SUMS) > "$AUDIT/checksums.log"
python "$AUDIT/check_table_independent.py" "$BUNDLE/code/table17.npy" > "$AUDIT/table_independent.log"
export MUB6_SKIP_TABLE_VERIFY=1
python "$AUDIT/focused_checks.py" "$BUNDLE/code" > "$AUDIT/focused_checks.json"
python "$AUDIT/check_resume.py" "$BUNDLE/code" > "$AUDIT/resume_check.json"
python "$AUDIT/check_cover_and_statistics.py" "$BUNDLE" > "$AUDIT/cover_statistics.log"
(cd "$BUNDLE/code" && python verify_cliques.py "$BUNDLE/results/results_merged.jsonl") > "$AUDIT/verify_cliques_rerun.log"
(cd "$BUNDLE/code" && python symcheck.py) > "$AUDIT/symmetry_rerun.log"
(cd "$BUNDLE/code" && python selftest.py 20260929 12) > "$AUDIT/selftest_rerun.log"
echo "Audit checks completed. Read README.md and JSON findings; this is not an end-to-end proof verification."
