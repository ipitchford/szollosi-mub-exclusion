"""Independent orchestration/data audit of the supplied v2 bundle; not a fresh full coverage replay."""
import os,sys,pathlib,json,hashlib,time,collections,subprocess,itertools
import numpy as np
ROOT=pathlib.Path(os.environ.get('MUB6_BUNDLE_DIR','/mnt/data/mub6_szollosi_certified_v2'))
OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'chk'))
import ck,run_check
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
start=time.time()
ck.load_table(str(ROOT/'gen/table17.npy'),verify=True)
report={'archive_sha256':sha(pathlib.Path(os.environ.get('MUB6_ARCHIVE_PATH',str(ROOT.with_suffix('.zip'))))),'fresh_table_check':True,'families':{}}
for name,gens,logs in [('szollosi',['gen_vm.jsonl','gen_vm_tail.jsonl','gen_mac.jsonl'],'chk_szollosi_all.jsonl'),('fourier',['gen_fourier.jsonl'],'chk_fourier.jsonl')]:
 fam=ck.Fam(name);fam.install()
 recs,n=run_check.load_records([str(ROOT/'results'/g) for g in gens])
 need,missing,kc=run_check.walk(fam,recs)
 done={}; modes=collections.Counter()
 for line in (ROOT/'chk_results'/logs).open():
  r=json.loads(line)
  for b in r['boxes']:done[(b['lev'],tuple(b['idx']))]=b
 mism=[];bad=[];bounds=[];selfbad=[];graphbad=[];stats=collections.Counter();splits=collections.Counter()
 for ii,k in enumerate(need):
  lo,hi=recs[k];b=done.get(k,{})
  h=hashlib.sha256(json.dumps([lo,hi]).encode()).hexdigest()[:16]
  if h!=b.get('hulls_sha'):mism.append(k)
  if not all(b.get(s) is True for s in ['ok','coverage','graphs']):bad.append(k)
  lo=np.asarray(lo,dtype=np.int64).reshape(-1,5);hi=np.asarray(hi,dtype=np.int64).reshape(-1,5)
  if np.any(hi<lo) or np.any(hi-lo>65536):bounds.append(k)
  ok,g=ck.verify_graphs(lo,hi)
  if not ok:graphbad.append([k,g])
  if g!=b.get('graph_info'):mism.append(['graph_info',k,g,b.get('graph_info')])
  stats['hulls']+=len(lo);stats['six_cliques']+=g.get('cliques',0);stats['boxes']+=1
  if 'split_detail' in b:splits[str(b['cov_stats']['split_level'])]+=1
  if ii%1000==0:print(name,ii,'of',len(need),'elapsed',round(time.time()-start,1),flush=True)
 complete,uncovered=run_check.evaluate(fam,{k:b['ok'] for k,b in done.items()})
 result=dict(records=n,certified_records=len(recs),needed=len(need),missing=missing,kept_counts=kc,hash_or_graph_mismatches=mism,bad_records=bad,invalid_hull_bounds=bounds,fresh_graph_failures=graphbad,stats=dict(stats),split_depth_histogram=dict(splits),cover_complete_from_recorded_replays=complete,uncovered=uncovered)
 report['families'][name]=result
 print(name,json.dumps(result),flush=True)
 # Explicitly test stale-cache acceptance: empty hulls plus unchanged positive replay records.
 # No claim these fabricated records occur in the submission.
 empty_recs={k:([],[]) for k in need}
 nneed,nmissing,_=run_check.walk(fam,empty_recs)
 unbound_accept=run_check.evaluate(fam,{k:True for k in nneed})[0]
 result['synthetic_unbound_resume_would_accept_empty_hulls']=unbound_accept
 (OUT/'data_graph_audit.json').write_text(json.dumps(report,indent=2,default=int))
# Closed-cell boundary counterexample for the selector's stated contract.
f=ck.Fam('szollosi');f.install()
idx=np.array([[0,128,511,256],[0,128,0,256]],dtype=np.int64)
keep=ck.select_szollosi(idx,9).tolist()
report['closed_cell_boundary_example']={'level':9,'indices':idx.tolist(),'kept':keep,'point_angle_units_of_2pi':['0','1/4','0 = 1 mod 1','1/2'],'alpha':1,'meaning':'Both closed torus cells contain the same fundamental-domain point; only the canonical half-open owner must be retained.'}
# Independently brute-force the supplied clique enumerator on random small graphs.
rng=np.random.default_rng(931)
for j in range(120):
 n=int(rng.integers(6,14)); p=float(rng.uniform(.2,.99));A=rng.random((n,n))<p; A=np.triu(A,1);A=A|A.T
 expected={k for k in itertools.combinations(range(n),6) if all(A[a,b] for a,b in itertools.combinations(k,2))}
 actual=set(ck.cliques6(A)[0]);assert expected==actual
report['independent_bruteforce_clique_tests']=120
report['elapsed_seconds']=time.time()-start
(OUT/'data_graph_audit.json').write_text(json.dumps(report,indent=2,default=int))
print('AUDIT COMPLETE',round(time.time()-start,1),flush=True)
