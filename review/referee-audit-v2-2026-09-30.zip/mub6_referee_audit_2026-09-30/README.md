# Independent referee audit: Szöllősi MUB exclusion, certified v2

Review date: 30 September 2026.
Source archive: `mub6_szollosi_certified_v2.zip`.
SHA-256: `d48764e5ca0ce38e47bf6df4b20b5abc230f9cebece5aa90ccaf5d393c674ce7`.

This audit is not a replacement certificate and does not modify the submitted paper.
The full editorial review appears in the accompanying conversation. These files preserve
executed checks, their outputs, and reproductions of specific concerns.

## Results and evidence limits

- All 149 original manifest entries checked successfully.
- The submitted C checker was rebuilt with its supplied strict floating-point flags.
- All eleven supplied checker test groups passed, including 1,385,847 off-centre stress boxes.
  Numerical solutions used by those tests are numerical witnesses, not separately certified roots.
- The complete table of 131,072 complex entries was freshly verified by the supplied interval checker.
- Parameter-cover trees and input/log consistency were checked for all 14,658 Szöllősi and 1,935 Fourier certificates.
- All 16,593 hull/graph certificates were freshly recomputed using the submitted checker. No mismatch or graph failure occurred.
- Fresh phase-space coverage was replayed for six stress-selected parent certificates (three per family).
- A seventh parent certificate, Szöllősi level 9 [133,378,227,284], was freshly replayed with parameter subdivision: six kept level-12 children passed. Less refined attempts failed conservatively.
- Supplied exact Szöllősi symmetry and Fourier Hadamard checks were rerun successfully.
- A separately written Python-integer program verified all 144 Fourier symmetry identities, group closure, and the 511,416 triangle-separation tests establishing the fundamental-domain tiling.
- A separately written brute-force comparison tested the supplied six-clique enumerator on 120 small graphs.

IMPORTANT: Complete phase-space coverage for every parameter box was NOT freshly rerun in this review.
For boxes outside the seven selected parents, the coverage evidence remains the submitted replay records,
whose input digests and reported source hashes matched the current submission. Full graph verification is
not the same task as full phase-space coverage. A fresh run of an author's checker is also not an
independently implemented interval checker. The independently authored integer and regression tests are
identified separately above.

## Findings

### A. Closed-cell statements versus half-open ownership

Theorem 7(O1), Lemma 11 and the subdivision paragraph in section 6.5 state stronger
closed-box properties than the selector establishes. The implementation can discard a closed box
that meets the fundamental domain on a shared boundary, while retaining the point's canonical
half-open owner. This does not demonstrate a gap in the global cover.

A non-wrapping example is in `nonwrapping_boundary_example.json`:
`t=pi/32`, `u=v=-exp(it)`, `w=exp(-2it)`,
`alpha=2 exp(it)-exp(-2it)`.
Here `D(-alpha)=0`, `D(alpha)=-16 Re(alpha^3)<0`, and alpha is strictly inside the chosen angular sector.
At level 9, the closed cell [34,106,264,263] contains this fundamental-domain point but is discarded;
its canonical owner [34,106,264,264] is retained. The x,y root locations are additionally checked by 50-digit interval sign changes and the intermediate value theorem in `boundary_reproduce.py` and `boundary_interval_checks.json`. A simpler torus-wrap example is also recorded in
`data_graph_audit.json`.

Repair: define half-open owner cells Q and their closed interval enclosures P=closure(Q).
Require the selector to retain the unique owner of each point of the fundamental domain along its
unique ancestor path. Require coverage only for points in F intersect Q, including the subdivision
argument. Theorem 7(O2) currently requires the stronger P intersect Sigma and must be reconciled too.
Do not merely change closed P intersect Sigma to closed P intersect F and leave the ownership issue unresolved.

### B. Unbound replay cache

`chk/run_check.py` reuses `ok` statuses keyed only by (level, indices), without validating that the
current hull data, family, table, checker and compiled kernel match the inputs that produced them.
The current final summary can attach current input/source hashes to old unchecked statuses.

`resume_regression.py` makes a TEMPORARY altered Fourier input, empties the hull list of exactly one
certificate, copies the original positive replay cache, and invokes the actual supplied driver.
It exits successfully and reports `cover_complete: true` and 1,935 verified boxes. This is an
intentional negative test, NOT an allegation that any supplied certificate or replay was corrupted.
All actual submitted hull digests matched in this audit.

Repair: content-address cached results with full hashes binding all proof inputs and code/build identities;
reject mismatches; add an explicit clean-output proof mode; include this negative test; retain one clean,
fully replayed record set and a sealed manifest. The optional MUB6_KERNEL override should be rejected or
explicitly identified by a recorded binary hash in proof mode.

### C. Transferability overstatement

Section 11.4 claims the larger Karlsson and four-parameter Szöllősi families can be handled by changing
input data and at most the selector, but without changing the kernel. No complete exponent/constraint
encoding or branch-cover proof is supplied. The implemented character-family interface and capacities
(MAXP=4, MAXT=8, MAXN=7, at most one complex family constraint) do not establish that claim.
Restrict it to demonstrated families or supply a complete encoding and verify its hypotheses.
This concern does not refute the current Szöllősi/Fourier exclusions.

### D. Smaller proof/reporting repairs

- Appendix A's induction with exponent c+8 fails when two uncertain inputs are multiplied. A simple
  exact rational reproduction is in `local_arithmetic_checks.py/json`. This refutes an intermediate
  proof claim, NOT the final padded bound in Lemma R, and the generator is outside the trusted proof path.
- Section 1.3's claim that mutation testing exercises every soundness ingredient must acknowledge
  the surviving omitted mixed-parameter term mutation reported in section 8.3.
  `local_arithmetic_checks.py` gives a generic exact Krawczyk assembly fixture showing why such a term
  matters. It is NOT a counterexample to the current C kernel, which includes the term.
- Section 6.5 should describe subdivision through level ell+3: eight recorded boxes needed level 12.
- Correct Theorem 7's reference to nonexistent section 6.6 and stale exact-script lemma labels.

## Main files

- `audit.py`, `audit.log`, `data_graph_audit.json`: cover tree, hashes, all graphs, table, small-graph test.
- `replay_selected.py`, `replay_selected.log`, `fresh_selected_replay.json`: six fresh phase replays.
- `fresh_split_replay.jsonl`, `fresh_split_replay.log`, `split_selected_boxes.json`: seventh phase replay.
- `fourier_independent.py/json/log`: independently implemented exact Fourier witnesses and tiling.
- `resume_regression.py`, its logs and JSON: actual command-line stale-cache regression.
- `local_arithmetic_checks.py/json`: exact local proof/test counterexamples, narrowly scoped as above.
- `kernel_tests.log`, `lemma5_exact.json/log`, `fourier_exact.json/log`: rerun supplied tests.
- `manifest_check.log`, `source_sha256.txt`, `environment.json`: provenance.

## Reproduction

Requires the original extracted source bundle, its Python dependencies, and a C compiler.
The source archive itself is not duplicated here. Reviewer scripts accept:

```sh
export MUB6_BUNDLE_DIR=/absolute/path/to/mub6_szollosi_certified_v2
export MUB6_ARCHIVE_PATH=/absolute/path/to/mub6_szollosi_certified_v2.zip
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
bash "$MUB6_BUNDLE_DIR/chk/build.sh"
python audit.py
python replay_selected.py
python fourier_independent.py
python resume_regression.py
python local_arithmetic_checks.py
python boundary_reproduce.py
python "$MUB6_BUNDLE_DIR/chk/tests/test_kernel.py"
python "$MUB6_BUNDLE_DIR/chk/verify_split.py" szollosi "$MUB6_BUNDLE_DIR/gen/table17.npy" \
  fresh_split_replay_new.jsonl "$MUB6_BUNDLE_DIR/results/gen_vm.jsonl" \
  "$MUB6_BUNDLE_DIR/results/gen_vm_tail.jsonl" "$MUB6_BUNDLE_DIR/results/gen_mac.jsonl" \
  --boxes split_selected_boxes.json --depth 3
```

Use the supplied build script's documented working directory if needed. The included logs were produced
before replacing fixed source-directory literals in reviewer scripts with environment-variable overrides;
no mathematical checking logic was changed by that portability edit. Rerunning scripts overwrites their
own JSON/log outputs but the regression uses a temporary copy and leaves original certificate data unchanged.

No external publication's full text or source archive is redistributed in this audit.
