"""Exact local proof/test fixtures; NOT counterexamples to the main MUB theorem or current kernel."""
from fractions import Fraction as F
from pathlib import Path
import json
u=F(1,2**53)
a=(1-u)**-8
actual=a*a
claimed_induction=(1-u)**-9+F(1,2**810)
assert actual>claimed_induction
# Generic mixed-parameter Krawczyk assembly example, independently of the MUB C kernel.
# f(w,q)=(1+q)w-5/2, W=[-1,1], Q=[0,2], w0=0,q0=1,Y=1/2.
w,q=F(5,6),F(2)
assert (1+q)*w-F(5,2)==0
bad_k=F(5,4)
assert bad_k>1
correct_k=(F(3,4),F(7,4))
assert correct_k[0] <= w <= correct_k[1] and -1<=w<=1
r={'lemma_R_induction_counterexample':{'input_exact':'(1-2^-53)^-8','computed_inputs':[1,1],'operation':'multiply','computed_result':1,'actual_exponent':16,'claimed_induction_exponent':9,'claimed_epsilon':'2^-810','strict_violation':True,'scope':'Intermediate induction only; final Lemma R bound is not refuted.'},'generic_Krawczyk_fixture':{'function':'(1+q)w-5/2','W':['-1','1'],'Q':['0','2'],'basepoint':['0','1'],'Y':'1/2','true_root':['5/6','2'],'omitted_mixed_term_K':['5/4','5/4'],'correct_K':['3/4','7/4'],'scope':'Generic assembly fixture, not a current-kernel counterexample.'}}
(Path(__file__).resolve().parent/'local_arithmetic_checks.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
