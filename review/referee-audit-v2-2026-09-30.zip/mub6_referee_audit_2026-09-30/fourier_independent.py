"""Independently check the recorded Fourier symmetries and fundamental-domain tiling using Python integers only."""
from pathlib import Path
from itertools import combinations_with_replacement, product
import json,time,os
R=Path(os.environ.get('MUB6_BUNDLE_DIR','/mnt/data/mub6_szollosi_certified_v2'));O=Path(__file__).resolve().parent;t0=time.time()
rows=json.loads((R/'fourier/fundamental_domain.json').read_text())['symmetries']
Z=[[0]*6,[0,1,2,3,4,5],[0,2,4,0,2,4],[0,3,0,3,0,3],[0,4,2,0,4,2],[0,5,4,3,2,1]]
E=[[(2*Z[i][j],int(i in [1,4] and j in [1,3,5]),int(i in [2,5] and j in [1,3,5])) for j in range(6)] for i in range(6)]
def getbase(g,i,j):
 if g in [2,3]:i,j=j,i
 v=E[i][j]
 return tuple(-a for a in v) if g in [1,3] else v
for row in rows:
 p,q,r,t,m,n=row['T'];perm=row['row_perm'];col=row['col_perm'];ds=row['D1_exponents'];es=row['D2_exponents'];g=row['variant']
 assert sorted(perm)==sorted(col)==list(range(6)) and abs(p*t-q*r)==1
 for i,j in product(range(6),repeat=2):
  z,x,y=E[i][j];target=(z+x*m+y*n,x*p+y*r,x*q+y*t);base=getbase(g,perm[i],col[j]);d=[target[k]-base[k]-ds[i][k]-es[j][k] for k in range(3)]
  assert d[0]%12==0 and d[1:]==[0,0]
keys={tuple(row['T'][:4]+[row['T'][4]%12,row['T'][5]%12]) for row in rows};assert len(keys)==144
for A,B in product(keys,repeat=2):
 p,q,r,t,m,n=A;P,Q,Rr,S,M,N=B
 C=(p*P+q*Rr,p*Q+q*S,r*P+t*Rr,r*Q+t*S,(p*M+q*N+m)%12,(r*M+t*N+n)%12)
 assert C in keys
assert (1,0,0,1,0,0) in keys
tri=[]
for p,q,r,t,m,n in sorted(keys):
 det=p*t-q*r
 verts=[((t*(x-m)-q*(y-n))//det,(-r*(x-m)+p*(y-n))//det) for x,y in [(0,0),(2,0),(2,1)]]
 sx=12*(verts[0][0]//12);sy=12*(verts[0][1]//12)
 verts=[(x-sx,y-sy) for x,y in verts];assert all(-12<x<24 and -12<y<24 for x,y in verts)
 tri.append(verts)
def twicearea(v):
 (a,b),(c,d),(e,f)=v;return abs((c-a)*(f-b)-(d-b)*(e-a))
assert sum(map(twicearea,tri))==288

def separate(a,b):
 for v in (a,b):
  for i in range(3):
   dx=v[(i+1)%3][0]-v[i][0];dy=v[(i+1)%3][1]-v[i][1]
   u=[-dy*x+dx*y for x,y in a];w=[-dy*x+dx*y for x,y in b]
   if max(u)<=min(w) or max(w)<=min(u):return True
 return False
checks=0
for i,j in combinations_with_replacement(range(144),2):
 for sx,sy in product(range(-3,4),repeat=2):
  if i==j and sx==sy==0:continue
  b=[(x+12*sx,y+12*sy) for x,y in tri[j]];assert separate(tri[i],b),(i,j,sx,sy);checks+=1
res={'all_144_exact_matrix_identities':True,'group_order':144,'group_closed':True,'tiling_area_exact':1,'integer_separation_tests':checks,'overlapping_interiors':0,'elapsed_seconds':time.time()-t0}
(O/'fourier_independent.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
