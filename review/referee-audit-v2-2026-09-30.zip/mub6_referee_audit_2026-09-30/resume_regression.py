"""Adversarial test only: demonstrate that the replay cache is not bound to current hull inputs.
Creates temporary ALTERED data, not a report of corruption in the submitted bundle.
"""
import pathlib,tempfile,json,subprocess,shutil,sys,os
R=pathlib.Path(os.environ.get('MUB6_BUNDLE_DIR','/mnt/data/mub6_szollosi_certified_v2'));O=pathlib.Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as td:
 t=pathlib.Path(td);cert=t/'altered_fourier.jsonl';cached=t/'cached.jsonl';changes=0
 with cert.open('w') as f:
  for s in (R/'results/gen_fourier.jsonl').open():
   r=json.loads(s)
   if r['lev']==9 and r['idx']==[0,0]:
    r['hull_lo']=[];r['hull_hi']=[];changes+=1
   f.write(json.dumps(r)+'\n')
 assert changes==1
 shutil.copyfile(R/'chk_results/chk_fourier.jsonl',cached)
 cmd=[sys.executable,str(R/'chk/run_check.py'),'fourier',str(R/'gen/table17.npy'),str(cached),'1',str(cert)]
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=os.environ|{'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'})
 (O/'resume_regression_driver.log').write_text(p.stdout)
 summary=json.loads(cached.with_name('cached_summary.json').read_text())
 summary['adversarial_test_note']='The origin certificate hulls were deliberately replaced by empty lists; the cached replay remains from the unaltered input. No allegation that the supplied bundle contains this mismatch.'
 summary['exit_code']=p.returncode;summary['changed_certificates']=changes
 (O/'resume_regression_result.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(summary,indent=2))
