"""Fresh original-checker coverage replay on stress-selected certificates. No generator computation is trusted."""
import os,sys,pathlib,json,time
import numpy as np
ROOT=pathlib.Path(os.environ.get('MUB6_BUNDLE_DIR','/mnt/data/mub6_szollosi_certified_v2'));OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'chk'));import ck,run_check
ck.load_table(str(ROOT/'gen/table17.npy'),verify=True)
results=[]
for name,gens,indices in [('szollosi',['gen_vm.jsonl','gen_vm_tail.jsonl','gen_mac.jsonl'],[[0,170,0,170],[19,137,203,322],[0,128,0,256]]),('fourier',['gen_fourier.jsonl'],[[0,0],[84,0],[85,0]])]:
 f=ck.Fam(name);f.install();run_check.G['fam']=f
 recs,_=run_check.load_records([str(ROOT/'results'/g) for g in gens]);groups={}
 for idx in indices:
  root=tuple(t>>2 for t in idx);lo,hi=recs[(9,tuple(idx))];groups.setdefault(root,[]).append((9,tuple(idx),lo,hi))
 for root,items in groups.items():
  print('REPLAY START',name,root,flush=True);res=run_check.process_root((root,items));res['family']=name;results.append(res)
  print(json.dumps(res),flush=True)
  (OUT/'fresh_selected_replay.json').write_text(json.dumps(results,indent=2))
print('ALL SELECTED REPLAYS COMPLETE',flush=True)
