"""Interval-supported non-wrapping counterexample to the CLOSED-cell selector statement.
No counterexample to global half-open-owner coverage is claimed.
"""
from pathlib import Path
import os,sys,json
import numpy as np
from mpmath import iv
iv.dps=50
R=Path(os.environ.get('MUB6_BUNDLE_DIR','/mnt/data/mub6_szollosi_certified_v2'))
sys.path.insert(0,str(R/'chk'))
import ck
ck.load_table(str(R/'gen/table17.npy'),verify=True)
f=ck.Fam('szollosi');f.install()
iv.dps=50
t=iv.pi/32
a=2*iv.cos(t)-iv.cos(2*t);b=2*iv.sin(t)+iv.sin(2*t)
assert a.a>0 and b.a>0 and (a-iv.sqrt(3)*b).a>0
# e^(-3i theta/2) f_alpha(e^(i theta)) = 2i g(theta).
def g(k):
 th=2*iv.pi*k/512
 return iv.sin(3*th/2)-a*iv.sin(th/2)-b*iv.cos(th/2)
brackets=[]
for lo in [34,106]:
 l,h=g(lo),g(lo+1)
 assert (l.b<0 and h.a>0) or (l.a>0 and h.b<0)
 brackets.append({'grid_bracket':[lo,lo+1], 'g_left_interval':str(l),'g_right_interval':str(h)})
# IVT supplies two distinct unit roots. Vieta supplies a third unit root since xyz=1.
# Their phase fractions place the third in (1-142/512,1-140/512), above y.
assert 1-142/512>107/512
idx=np.array([[34,106,264,263],[34,106,264,264]],dtype=np.int64)
kept=ck.select_szollosi(idx,9).tolist();assert kept==[False,True]
r={'interval_precision_decimal':50,'alpha_real_interval':str(a),'alpha_imag_interval':str(b),'sector_margin_interval':str(a-iv.sqrt(3)*b),'unit_root_brackets':brackets,'indices':idx.tolist(),'kept':kept,'exact_repeated_root_phase_fraction':'264/512','reason':'u=v=-exp(i*pi/32), w=exp(-i*pi/16); alpha=2exp(i*pi/32)-exp(-i*pi/16). IVT brackets locate ordered unit roots x,y; Vieta gives ordered unit z. The first CLOSED cell contains a fundamental-domain point on its upper v boundary and is discarded; the second is its retained half-open owner.'}
(Path(__file__).resolve().parent/'boundary_interval_checks.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
